import {adminpage} from '../test/adminpage'
import { browser } from 'protractor';
describe("open url ",async()=>
  {
    var index=1;
    let admin=new adminpage()
    jasmine.DEFAULT_TIMEOUT_INTERVAL =600000;
    beforeEach(function() {
      return browser.ignoreSynchronization = true;
   });
    it("openurl",async()=>
    {
      const   url="http://automationpractice.com/index.php?controller=authentication&back=my-account"
      expect(index).toBe(1);
      index++;
     await admin.login()
     
    expect(await browser.driver.getTitle()).toBe("My account - My Store");
     console.log("completed")
    })
    it('log and login and evrify user',async()=>
    {
      expect(index).toBe(2);
      index++;
      await admin.verifyuser();
      expect(await admin.username).toBe('anilkumar')
     
    })
})