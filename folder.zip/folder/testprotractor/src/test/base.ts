import { browser,Config,element,by,ExpectedConditions, protractor } from 'protractor'
export class base
{
    waittimeout:number=5000;
    constructor()
    {

    }
    
 public async openurl(targeturl:string )
 {
     browser.waitForAngularEnabled(false);

      browser.get(targeturl);
      browser.driver.manage().window().maximize();
      console.log("opened url")
    
   
}

public async elementbyxpath(ele:string,waittimeout=50000)
{
const selector= element(by.xpath(ele));
var until = protractor.ExpectedConditions;
browser.wait(until.presenceOf(selector), 50000, 'Element taking too long to appear in the DOM');
return selector;

}
public async elementbylinktext(ele:string,waittimeout=50000)
{
const selector= element(by.linkText(ele));
var until = protractor.ExpectedConditions;
browser.wait(until.presenceOf(selector), 50000, 'Element taking too long to appear in the DOM');
return selector;

}
public async elementbyID(ele:string,waittimeout=50000)
{
const selector= element(by.id(ele));

return selector;

}
public async elementbyname(ele:string,waittimeout=50000)
{
const selector= element(by.className(ele));

return selector;

}
public async elementbycss(ele:string,waittimeout=50000)
{
const selector= element(by.css(ele));

return selector;

}
}