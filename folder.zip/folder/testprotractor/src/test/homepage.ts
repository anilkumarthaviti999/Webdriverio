import {base} from './base'
import {adminpage} from './adminpage';

class homepage extends base
{
    constructor() {
        super();
    }
 
admin1=new adminpage();

test()
{
}

}