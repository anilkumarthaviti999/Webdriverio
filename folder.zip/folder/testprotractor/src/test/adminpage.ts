import { base } from "./base";
import{browser,element,by} from 'protractor'
var faker=require('faker');
export class adminpage extends base{
    public username:string
    public randommail:string;
    constructor() {
        super();
        
    }
   
     
    delay(ms:number){
        return new Promise(res => setTimeout(res, ms));
      }
public async login()
{
    
    const ele1="//a[@class='login']";
    const ele2="//input[@name='email_create']";
    const ele3="//button[@name='SubmitCreate']";
    const ele4="//input[@id='id_gender1']";
    const ele5="//input[@id='customer_firstname']";
    const ele6="//input[@id='customer_lastname']";
    const ele7="//input[@id='passwd']";
    const ele8="//input[@id='address1']";
    const ele9="//input[@id='city']";
    const ele10="//select[@id='id_state']/option[3]";
    const ele11="//input[@id='postcode']";
    const ele12="//select[@id='id_country']";
    const ele13="//input[@id='phone_mobile']";
    const ele14="//button[@id='submitAccount']";
    const url='http://automationpractice.com/index.php?controller=authentication&back=my-account';
    
    this.openurl(url)
    this.delay(50000);
    console.log(" login method finished")
   const loginbtn= await this.elementbyxpath(ele1);
   loginbtn.click();
   const createbtn=await this.elementbyxpath(ele2);
    this.randommail=faker.internet.email();
   createbtn.sendKeys(this.randommail);
   const submitcreate=await this.elementbyxpath(ele3);
   submitcreate.click();
   this.delay(50000);
   const gender=await this.elementbyxpath(ele4);
   gender.click();
   const fname=await this.elementbyxpath(ele5);
   fname.sendKeys("anil");
   const lname=await this.elementbyxpath(ele6);
   lname.sendKeys("kumar");
   const passwd=await this.elementbyxpath(ele7);
   passwd.sendKeys("123456");
   const addr=await this.elementbyxpath(ele8);
   addr.sendKeys("aaaa");
   const city=await this.elementbyxpath(ele9);
   city.sendKeys("hyderbad");
   const state=await this.elementbyxpath(ele10);
   state.click();
   const postcode=await this.elementbyxpath(ele11);
   postcode.sendKeys("00000");
   const phone=await this.elementbyxpath(ele13);
   phone.sendKeys("9999999999");
   console.log(browser.getTitle());
   const submit=await this.elementbyxpath(ele14);
   await submit.click();
   browser.sleep(50000)
   
}

public async verifyuser()
{
const ele15="Sign out";
const ele16="Sign in";
const ele17="//input[@id='email']";
const ele18="//input[@id='passwd']";
const ele19="//button[@id='SubmitLogin']";
const ele20="//a[@class='account']";
const ele21="//a[@title='Dresses']";
const ele22="//a[@title='Casual Dresses']";
const signout=await this.elementbylinktext(ele15);
await signout.click();
const signin=await this.elementbylinktext(ele16);
await signin.click();
const email=await this.elementbyxpath(ele17);
await email.sendKeys(this.randommail);
const passwd=await this.elementbyxpath(ele18);
await passwd.sendKeys("123456");
const sbtn=await this.elementbyxpath(ele19);
await sbtn.click();
const account=await this.elementbyxpath(ele20);
this.username=await account.getText();
}
} 