import {  browser,Config } from 'protractor';

let SpecReporter = require('jasmine-spec-reporter').SpecReporter;
export let config: Config = {

    allScriptsTimeout: 110000,
    framework: 'jasmine',
    capabilities: {
      browserName: 'chrome'
    },
    

  onPrepare: function(){

    jasmine.getEnv().addReporter(new SpecReporter({

      displayFailuresSummary: true,

      displayFailuredSpec: true,

      displaySuiteNumber: true,

      displaySpecDuration: true

    }));

  },
    suites:{
    specs: 'src/specs/*spec.js' ,
    },
    seleniumServerJar: 'node_modules/protractor/node_modules/webdriver-manager/selenium/selenium-server-standalone-3.2.0.jar',
    seleniumAddress: 'http://localhost:4444/wd/hub'
}