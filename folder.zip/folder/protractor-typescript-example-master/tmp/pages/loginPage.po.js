"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
const basePage_po_1 = require("./basePage.po");
/**
 * Class representing generic page.
 * Methods/properties for global elements should go here.
 *
 * @export
 * @class loginPage
 */
class loginPage extends basePage_po_1.BasePage {
    loginPageHeader() {
        return protractor_1.element(protractor_1.by.xpath('.//*[@id=\'validate-form\']/h2[1]'));
    }
    userNameTextBox() {
        return protractor_1.element(protractor_1.by.id('user_email'));
    }
    userPasswordTextBox() {
        return protractor_1.element(protractor_1.by.id('user_password'));
    }
    loginSubmitButton() {
        return protractor_1.element(protractor_1.by.id('submit'));
    }
    /**
     * Opens global header's Institutional Sign In modal and
     * signs in using specified username/password.
     *
     * @param {string} username Username to login as
     * @param {string} password Password to login as
     */
    login(loginData) {
        const usernameInput = protractor_1.element(protractor_1.by.id('user_email'));
        const passwordInput = protractor_1.element(protractor_1.by.id('user_password'));
        const submitButton = protractor_1.element(protractor_1.by.id('submit'));
        usernameInput.sendKeys(loginData.username);
        passwordInput.sendKeys(loginData.password);
        submitButton.click();
    }
    /**
     * Navigates browser to a page on Xplore,
     * using baseUrl from params passed in.
     * Should use relative URL (eg '/Xplore/home.jsp').
     *
     * @param {string} relativeUrl Path of URL after the host (eg '/Xplore/home.jsp').
     * @memberof BasePage
     */
    navigateTo(relativeUrl) {
        protractor_1.browser.get(protractor_1.browser.params.baseUrl + relativeUrl);
    }
}
exports.loginPage = loginPage;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW5QYWdlLnBvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vcGFnZXMvbG9naW5QYWdlLnBvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsMkNBQW9FO0FBQ3BFLCtDQUF1QztBQUV2Qzs7Ozs7O0dBTUc7QUFDSCxlQUF1QixTQUFRLHNCQUFRO0lBRW5DLGVBQWU7UUFDWCxNQUFNLENBQUMsb0JBQU8sQ0FBQyxlQUFFLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQsZUFBZTtRQUNYLE1BQU0sQ0FBQyxvQkFBTyxDQUFDLGVBQUUsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsbUJBQW1CO1FBQ2YsTUFBTSxDQUFDLG9CQUFPLENBQUMsZUFBRSxDQUFDLEVBQUUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxpQkFBaUI7UUFDYixNQUFNLENBQUMsb0JBQU8sQ0FBQyxlQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILEtBQUssQ0FBQyxTQUFTO1FBQ1gsTUFBTSxhQUFhLEdBQUcsb0JBQU8sQ0FBQyxlQUFFLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDbkQsTUFBTSxhQUFhLEdBQUcsb0JBQU8sQ0FBQyxlQUFFLENBQUMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7UUFDdEQsTUFBTSxZQUFZLEdBQUcsb0JBQU8sQ0FBQyxlQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDOUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0MsYUFBYSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0MsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsVUFBVSxDQUFDLFdBQW1CO1FBQzFCLG9CQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUMsQ0FBQztJQUN0RCxDQUFDO0NBQ0o7QUE3Q0QsOEJBNkNDIn0=