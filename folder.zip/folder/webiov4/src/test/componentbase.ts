export default class componentbase
{
constructor() {
    
}
 openurl()
    {
        browser.url('http://E14123S1L:8180/btrademft');
        browser.windowHandleMaximize();
        console.log('openurl login method')
       
    }
}