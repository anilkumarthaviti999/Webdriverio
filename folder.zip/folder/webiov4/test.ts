
describe("test 1", function(){
it("test case", function(){
    browser.url("https://webdriver.io");

})
});