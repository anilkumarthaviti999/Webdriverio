
//var LoginPage=require('./Loginpage')
//var ComponentBase=require('./componentbase')
//var webdriver = require('selenium-webdriver');
//var LoginPage=require('./Loginpage')
// The pref exposes console errors to the tests

import {Admin} from '../test/Admin'
import {ComponentBase} from '../test/componentbase'
import { Driver } from 'selenium-webdriver/firefox';
/*
describe('Admin',()=>
{
let admin:Admin;
beforeAll(function(){
jasmine.DEFAULT_TIMEOUT_INTERVAL =600000;
admin = new Admin();
});
it('openurl',async ()=>
{
await admin.openurl();
expect(await admin.driver.getTitle()).toContain("Login");
})
it('credentials',async()=>
{
 await admin.credentials();
 //console.log(await login.driver.getTitle());
 expect(await admin.driver.getTitle()).toContain("TDXchange");
})

afterAll(function()
{
    // login.driver.quit();
})
});

*/
describe('Admin',async()=>
{
    let admin:Admin;
    beforeAll(function(){
        jasmine.DEFAULT_TIMEOUT_INTERVAL =600000;
        admin = new Admin();
        });
    it('open the url',async()=>
    {
        await admin.openurl();
    })
    it('Signup',async()=>
    {
await admin.Signup();
expect(await admin.driver.getTitle()).toBe("My account - My Store");
    })
    it('Verify the user',async()=>
    {
        await admin.Verifyuser();
     expect(admin.username).toBe("anil kumar")
    })
})

