import { homepage } from '../test/homepage';

describe("homepage", async()=>
{
    let home:homepage;
    jasmine.DEFAULT_TIMEOUT_INTERVAL =600000;
    home=new homepage();
   it("select dress catagory and click on casuals",async()=>
   
   {
       await home.dresscatalogcasual();
       expect(home.driver.getTiltle()).toBe("My account - My Store");
   })

})

