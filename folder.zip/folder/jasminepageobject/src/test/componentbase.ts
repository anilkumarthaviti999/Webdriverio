// Base class for all components including page-base and spa-page-base
import {By, Builder, ActionSequence} from 'selenium-webdriver';
import { Driver } from 'selenium-webdriver/ie';
import {Selector} from 'testcafe'
export class ComponentBase {
    driver: any;
    waitTimeout: number;
    log: (myVar: any) => boolean;
    
    delay(ms:number){
      return new Promise(res => setTimeout(res, ms));
    }
    constructor()
     {
      console.log("invoked")
      this.driver= new Builder().forBrowser('chrome').build()
      this.log = (myVar: any) => process.stdout.write(`${myVar}\n`)
      }

    async navigate(targeturl:string)
    {
        await this.driver.get(targeturl);
        //await this.driver.manage().window().maximize();
    }

     selectDropdownbyNum = function ( element:any, optionNum:number ) {
      if (optionNum){
        var options =  element.all(By.tagName('option'))   
          .then(function(options:any){
            options[optionNum].click();
          });
      }
    };
     async  mousehover(ele1:string,ele2:string) 
    {
      /*const actions = this.driver.actions({bridge: true}); 
      var elem=await this.driver.findElement(By.xpath(ele))
       await actions.move(elem,0,0).perform();
      */
      // action=new ActionSequence(this.driver);
      // this.driver.actions({bridge: true}).move({x: 10, y: 10, origin: ele1}).click().perform();
        //this.driver.findElement(By.xpath(ele2)).click();
      //await this.driver.execute(this.driver.findElement(By.xpath(ele1))).perform();
      /*const e1=await this.waitforElementByID(ele1,this.waitTimeout)
      this.driver.executeScript("arguments[0].click()",e1);
      const e2=await this.waitforElementByID(ele2,this.waitTimeout);
      e2.click();
*/
await this.delay(15000);
const e1=await this.waitforElementByID(ele1,this.waitTimeout)
await this.delay(15000);
const e2=await this.waitforElementByID(ele2,this.waitTimeout)
this.driver.executeScript("if(document.createEvent){" +
            "var hoverEventObj = document.createEvent('MouseEvents');" +
            "hoverEventObj.initEvent('mouseover',true,false);" +
            "arguments[0].dispatchEvent(hoverEventObj);" +
            "}" +
            "else if(document.createEventObject){" +
            "arguments[0].fireEvent('onmouseover');" +
            "}arguments[1].click();", e1, e2);
    }
   
    async clickWhenClickableByCss(cssName: any, waitTimeout = 10000) {
      const element = await this.waitForElementByCss(cssName, waitTimeout);
      await this.clickWhenClickable(element, waitTimeout);
    }
  
    // wait for named element to be clickable and then click it
    async clickWhenClickableByName(elementName: any, waitTimeout = 10000) {
      const element = await this.waitForElementByName(elementName, waitTimeout);
      await this.clickWhenClickable(element, waitTimeout);
    }
    async clickWhenClickableByxpath(xpath:any,waitTimeout=50000)
    {
      const element=await this.waitForElementByXpath(xpath,waitTimeout);
      await this.clickWhenClickable(element,waitTimeout);
    }
    async clickWhenClickableByID(elementId:any,waitTimeout=50000)
    {
      const element=await this.waitforElementByID(elementId,waitTimeout);
      await this.clickWhenClickable(element,waitTimeout);
    }
    
    async clickWhenClickable(element: { click: () => void; }, waitTimeout = 10000) {
      await this.driver.wait(this.driver.until.elementIsVisible(element), waitTimeout);
      await this.driver.wait(this.driver.until.elementIsEnabled(element), waitTimeout);
      await element.click();
    }
  
    async waitForElementByCss(elementcss: any, waitTimeout = 10000) {
      await this.delay(15000);
      const selector = await this.driver.findElement(By.css(elementcss));
      //const result = await this.waitForElement(selector, cssName, waitTimeout);
      return selector;
    }
  
    async waitForElementByName(elementName: any, waitTimeout = 10000) {
      const selector = this.driver.By.name(elementName);
      const result = await this.waitForElement(selector, elementName, waitTimeout);
      return selector;
    }
   async waitforElementByID(elementID:any,waitTimeout=50000)
   {
  
     //elementID= elementID.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").trim()
     console.log(elementID);
     //console.log(elementId);

    
  await this.delay(15000);
     console.log('title : ',await this.driver.getTitle());
     const selector=  await this.driver.findElement(By.xpath(elementID));
    // console.log(selector);
    
     return selector;
   }
   async waitforElementByLinktext(elementID:any,waitTimeout=50000)
   {
  
     //elementID= elementID.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").trim()
     console.log(elementID);
     //console.log(elementId);

    
  await this.delay(15000);
     console.log('title : ',await this.driver.getTitle());
     const selector=  await this.driver.findElement(By.linkText(elementID));
    // console.log(selector);
    
     return selector;
   }
    async waitForElement(selector: any, elementName: any, waitTimeout: number) {
      let result;
      await this.driver.wait(() =>
        this.driver.findElement(selector)
          .then(
            (element: any) => {
              result = element;
              return true;
            },
            (err: { name: string; }) => {
              if (err.name === 'NoSuchElementError') {
                return false;
              }
              return true;
            },
          ), waitTimeout, `Unable to find element: ${elementName}`);
      return result;
    }
  
    async waitForElementsByCss(cssName: any, waitTimeout = 10000) {
      const selector = this.driver.By.css(cssName);
      const result = await this.waitForElements(selector, cssName, waitTimeout);
      return result;
    }
    async waitForElementByXpath(Xpath:any,waitTimeout=20000)
    {
      console.log("xpath")
      const selector=this.driver.By.xpath(Xpath);
      //const result=await this.waitForElements(selector,Xpath,waitTimeout);
      return selector;
    }
    async waitForElements(selector: any, elementsName: any, waitTimeout: number) {
      let result;
      await this.driver.wait(() =>
        this.driver.findElements(selector)
          .then(
            (elements: any) => {
              result = elements;
              return true;
            },
            (err: { name: string; }) => {
              if (err.name === 'NoSuchElementsError') {
                return false;
              }
              return true;
            },
          ), waitTimeout, `Unable to find elements: ${elementsName}`);
      return result;
    }
  
    // output the messages from the webdriver browser console
    // Note: after we watch this for a while - we may want to add some asserts
    async dumpWebDriverLogs() {
      await this.driver.manage().logs().get('browser').then((logs: { length: number; forEach: (arg0: (log: any) => void) => void; }) => {
        if (logs.length === 0) {
          this.log('- No items found in webdriver log');
        }
        this.log(`- logs.length: ${logs.length}`);
        logs.forEach((log: { message: any; }) => {
          this.log(`- ${log.message}`);
        });

      });
    
    }
    
  }
  

  