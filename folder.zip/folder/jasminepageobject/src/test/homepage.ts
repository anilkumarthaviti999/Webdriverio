
import {ComponentBase} from './componentbase'
import { AssertionError } from 'assert';

import { promises } from 'fs';
const assert = require('assert');
import{Admin} from './Admin'
import { promise } from 'selenium-webdriver';
var webdriver=require('selenium-webdriver');
export class homepage extends ComponentBase
{
  webdriver:any;
  constructor()
  {
    super();
  }
  delay(ms:number){
    return new Promise(res => setTimeout(res, ms));

  }
  /*async createOrganization()
  {
    console.log("createorganization method starts")
    const ele1="div.rf-ac-itm-lbl-inact > table > tbody > tr > td";
    const ele2="Fast Setup";
    const ele3="//input[contains(@name,'domainNameField:domainNameInput')]";
    const ele4="//input[contains(@name,'organizationNameField:organizationNameInput')]";
    const ele5="//input[contains(@name,'departmentNameField:departmentNameInput')]";
    const ele6="//input[contains(@name,'divisionNameField:divisionName')]"

    const orglink=await this.waitForElementByCss(ele1,this.waitTimeout);
    orglink.click();
    const fastsetup=await this.waitforElementByLinktext(ele2,this.waitTimeout);
    fastsetup.click();
    const dom=await this.waitForElementByXpath(ele3,this.waitTimeout);
    dom.senKeys("TP1");
    const orname=await this.waitForElementByXpath(ele4,this.waitTimeout);
    orname.senKeys("TP1");
    const dep=await this.waitForElementByXpath(ele5,this.waitTimeout);
    dep.senKeys("TP1");
    const div=await this.waitForElementByXpath(ele6,this.waitTimeout);
    div.sendKeys("TP1");
  }
    */

async dresscatalogcasual()
{
  
  const ele21="//a[@title='Dresses']";
  const ele22="//a[@title='Casual Dresses']";
  await this.mousehover(ele21,ele22);
  console.log(this.driver.getTitle());
}
  
}
