// Functionality for both external and internal page object
const assert = require('assert');
//var ComponentBase = require('./componentbase');
//var webdriver=require('./selenium-webdriver')
const username = "system";
const password = "1234567890";
import {ComponentBase} from './componentbase'
import { AssertionError } from 'assert';
import { By } from 'selenium-webdriver';
var faker=require('faker');
var webdriver=require('selenium-webdriver');
export class Admin extends ComponentBase
 {
  webdriver: any;
  username:string;
  randomname:string; 
constructor()
  {
  super();
 // targetUrl = "http://E14123S1L:8180/btrademft";
  }
  delay(ms:number){
    return new Promise(res => setTimeout(res, ms));
  }
 async  openurl()
{
  //http://automationpractice.com/index.php?controller=authentication&back=my-account
 await this.navigate("http://automationpractice.com/index.php?controller=authentication&back=my-account");
 await this.driver.manage().window().maximize();
 await this.delay(10000);

//const dress=await this.driver.findElement(By.xpath(ele22));
//await dress.click();
}

/*
async credentials () {


  //await driver.wait(until.elementIsVisible(await driver.findElement(By.css("article.contact"))),10000);

  // fill out form
 
  //await this.driver.findElement(this.By.id("loginForm:username")).sendKeys(username);
  const ele:any="//input[contains(@id,'username')]";
  const ele1:any="//input[contains(@id,'password')]";
  const ele3:any="//input[contains(@id,'submit')]";
  const usr= await this.waitforElementByID(ele,this.waitTimeout);
  await usr.sendKeys(username);
  const pwd=await this.waitforElementByID(ele1,this.waitTimeout);
  await pwd.sendKeys(password);
  const loginbtn=await this.waitforElementByID(ele3,this.waitTimeout);
  await loginbtn.click();
  
  //await this.driver.findElement(this.By.id("loginForm:password")).sendKeys(password);
  //await this.driver.findElement(this.By.id("loginForm:submit")).click()
 }
  */

async Signup()
{
  const ele1="//a[@class='login']";
  const ele2="//input[@name='email_create']";
  const ele3="//button[@name='SubmitCreate']";
  const ele4="//input[@id='id_gender1']";
  const ele5="//input[@id='customer_firstname']";
  const ele6="//input[@id='customer_lastname']";
  const ele7="//input[@id='passwd']";
  const ele8="//input[@id='address1']";
  const ele9="//input[@id='city']";
  const ele10="//select[@id='id_state']/option[3]";
  const ele11="//input[@id='postcode']";
  const ele12="//select[@id='id_country']";
  const ele13="//input[@id='phone_mobile']";
  const ele14="//button[@id='submitAccount']";

  const loginbtn=await this.waitforElementByID(ele1,this.waitTimeout);
  loginbtn.click();
  const createbtn=await this.waitforElementByID(ele2,this.waitTimeout);
  this.randomname=faker.internet.email();
  createbtn.sendKeys(this.randomname);
  const submitcreate=await this.waitforElementByID(ele3,this.waitTimeout);
  submitcreate.click();
  const gender=await this.waitforElementByID(ele4,this.waitTimeout);
  gender.click();
  const fname=await this.waitforElementByID(ele5,this.waitTimeout);
  fname.sendKeys("anil");
  const lname=await this.waitforElementByID(ele6,this.waitTimeout);
  lname.sendKeys("kumar");
  const passwd=await this.waitforElementByID(ele7,this.waitTimeout);
  passwd.sendKeys("123456");
  const addr=await this.waitforElementByID(ele8,this.waitTimeout);
  addr.sendKeys("aaaa");
  const city=await this.waitforElementByID(ele9,this.waitTimeout);
  city.sendKeys("hyderbad");
  const state=await this.waitforElementByID(ele10,this.waitTimeout);
  state.click();
  const postcode=await this.waitforElementByID(ele11,this.waitTimeout);
  postcode.sendKeys("00000");
  const phone=await this.waitforElementByID(ele13,this.waitTimeout);
  phone.sendKeys("9999999999");
  console.log(this.driver.getTitle());
  const submit=await this.waitforElementByID(ele14,this.waitTimeout);
  await submit.click();
this.delay(15000);
}

async Verifyuser()
{
const ele15="Sign out";
const ele16="Sign in";
const ele17="//input[@id='email']";
const ele18="//input[@id='passwd']";
const ele19="//button[@id='SubmitLogin']";
const ele20="//a[@class='account']";
const ele21="//a[@title='Dresses']";
const ele22="//a[@title='Casual Dresses']";
const signout=await this.waitforElementByLinktext(ele15,this.waitTimeout);
await signout.click();
const signin=await this.waitforElementByLinktext(ele16,this.waitTimeout);
await signin.click();
const email=await this.waitforElementByID(ele17,this.waitTimeout);
await email.sendKeys(this.randomname);
const passwd=await this.waitforElementByID(ele18,this.waitTimeout);
await passwd.sendKeys("123456");
const sbtn=await this.waitforElementByID(ele19,this.waitTimeout);
await sbtn.click();
const account=await this.waitforElementByID(ele20,this.waitTimeout);
this.username=await account.getText();
//await this.mousehover(ele21);

}
 

}
