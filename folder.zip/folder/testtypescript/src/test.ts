export class test
{
    async sum()
    {
        var x=5;
        console.log("sum is" +x);
        return x;
    }
}
