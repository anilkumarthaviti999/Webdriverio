import { test } from './test'

describe('test',async()=>
{
    let a:test;
   a=new test();
  it('sum',async ()=>
  {
  expect(await a.sum()).toBe(5)
  })
})